pi = 3.14

def area(r):
    '''
    input: radius
    output: area
    '''
    return r**2 * pi

def circumference(r):
    '''
    input: radius
    output: circumference
    '''
    return r * 2 * pi